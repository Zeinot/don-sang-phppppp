<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Users\tshopira\Downloads\project\don-sang-php\resources\views/livewire/list-posts.blade.php ENDPATH**/ ?>