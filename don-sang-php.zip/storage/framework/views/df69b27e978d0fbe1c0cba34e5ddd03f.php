<?php $__env->startSection("body"); ?>

    <main class="my-24 md:mx-10 mx-5 ">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dev-tools', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1596535686-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <section class="lg:flex lg:justify-center">
            <div class="xl:w-3/4 lg:w-4/5 w-full mb-4">



                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('list-posts', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1596535686-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>
        </section>
    </main>
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.basic", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tshopira\Downloads\project\don-sang-php\resources\views/posts.blade.php ENDPATH**/ ?>