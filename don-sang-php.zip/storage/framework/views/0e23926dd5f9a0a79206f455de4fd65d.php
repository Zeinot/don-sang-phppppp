<?php $__env->startSection("body"); ?>
    <?php if (isset($component)) { $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $attributes; } ?>
<?php $component = App\View\Components\Hero::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Hero::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $attributes = $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $component = $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal365b1ee35a662db8d6d8b36f0320003c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal365b1ee35a662db8d6d8b36f0320003c = $attributes; } ?>
<?php $component = App\View\Components\FeatureCta::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature-cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FeatureCta::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal365b1ee35a662db8d6d8b36f0320003c)): ?>
<?php $attributes = $__attributesOriginal365b1ee35a662db8d6d8b36f0320003c; ?>
<?php unset($__attributesOriginal365b1ee35a662db8d6d8b36f0320003c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal365b1ee35a662db8d6d8b36f0320003c)): ?>
<?php $component = $__componentOriginal365b1ee35a662db8d6d8b36f0320003c; ?>
<?php unset($__componentOriginal365b1ee35a662db8d6d8b36f0320003c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal7a111c670635eef4aef3686ceb1d67ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a111c670635eef4aef3686ceb1d67ee = $attributes; } ?>
<?php $component = App\View\Components\ImageCta::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ImageCta::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a111c670635eef4aef3686ceb1d67ee)): ?>
<?php $attributes = $__attributesOriginal7a111c670635eef4aef3686ceb1d67ee; ?>
<?php unset($__attributesOriginal7a111c670635eef4aef3686ceb1d67ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a111c670635eef4aef3686ceb1d67ee)): ?>
<?php $component = $__componentOriginal7a111c670635eef4aef3686ceb1d67ee; ?>
<?php unset($__componentOriginal7a111c670635eef4aef3686ceb1d67ee); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf94a1174bdbe32dffeaf4f2faf7c711d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94a1174bdbe32dffeaf4f2faf7c711d = $attributes; } ?>
<?php $component = App\View\Components\SocialProof::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social-proof'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SocialProof::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94a1174bdbe32dffeaf4f2faf7c711d)): ?>
<?php $attributes = $__attributesOriginalf94a1174bdbe32dffeaf4f2faf7c711d; ?>
<?php unset($__attributesOriginalf94a1174bdbe32dffeaf4f2faf7c711d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94a1174bdbe32dffeaf4f2faf7c711d)): ?>
<?php $component = $__componentOriginalf94a1174bdbe32dffeaf4f2faf7c711d; ?>
<?php unset($__componentOriginalf94a1174bdbe32dffeaf4f2faf7c711d); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala3869b2048fa217e2bd54791ad840539 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3869b2048fa217e2bd54791ad840539 = $attributes; } ?>
<?php $component = App\View\Components\ImageGallery::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ImageGallery::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3869b2048fa217e2bd54791ad840539)): ?>
<?php $attributes = $__attributesOriginala3869b2048fa217e2bd54791ad840539; ?>
<?php unset($__attributesOriginala3869b2048fa217e2bd54791ad840539); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3869b2048fa217e2bd54791ad840539)): ?>
<?php $component = $__componentOriginala3869b2048fa217e2bd54791ad840539; ?>
<?php unset($__componentOriginala3869b2048fa217e2bd54791ad840539); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.basic", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tshopira\Downloads\project\don-sang-php\resources\views/home.blade.php ENDPATH**/ ?>