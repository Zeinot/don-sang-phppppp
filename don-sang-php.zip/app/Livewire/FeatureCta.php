<?php

namespace App\Livewire;

use Livewire\Component;

class FeatureCta extends Component
{
    public function render()
    {
        return view('livewire.feature-cta');
    }
}
