## Don de sang
 

<a href="https://youtu.be/7Ym3XOUrGFc?list=PLqDySLfPKRn6fgrrdg4_SmsSxWzVlUQJo">Filament Course </a>

1. [ ] Make relationship for post and location
2. [ ] Add search
3. [ ] Add column picker
4. [ ] Add delete action
5. [ ] Add bulk delete action

HERE :
https://youtu.be/c_hL4wKYfHY?list=PLqDySLfPKRn6fgrrdg4_SmsSxWzVlUQJo&t=234
