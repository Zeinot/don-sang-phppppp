<div>
{{--     Knowing others is intelligence; knowing yourself is true wisdom.--}}
    {{$this->productInfolist}}
{{--    {{ $getActionFunction("Book") }}--}}
</div>
