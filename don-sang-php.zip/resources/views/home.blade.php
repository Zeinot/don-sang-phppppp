@extends("layouts.basic")
@section("body")
    <x-hero/>
    <x-feature-cta/>
    <x-image-cta/>
    <x-social-proof/>
    <x-image-gallery/>
@endsection

